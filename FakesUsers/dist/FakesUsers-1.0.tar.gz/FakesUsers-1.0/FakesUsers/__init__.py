import random

from .FakeUsers import Fu